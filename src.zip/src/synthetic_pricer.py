import pandas as pd
import numpy as np
from typing import Dict, Optional, Union, List, Any
import sys
import os
import config

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class SyntheticPricer:
    """Calculate synthetic financing costs and compare with cash"""

    def __init__(self):
        """Initialize with financing parameters"""
        cfg = config.FINANCING_CONFIG
        self.sofr_rate = cfg.get('sofr_rate', 0.045)
        self.base_spread = cfg.get('base_spread', 0.0015)
        self.vol_coefficient = cfg.get('vol_coefficient', 0.002)
        self.days_per_year = cfg.get('financing_days_per_year', 360)

    def _financing_cost(self, rate: float, notional: float, days: int) -> float:
        """Simple financing cost calculation"""
        return rate * notional * (days / self.days_per_year)

    def _get_dividend_yield(self, ticker: str, price: float, dividend_yields: pd.DataFrame) -> float:
        """Extract dividend yield for a ticker"""
        return dividend_yields[ticker].iloc[-1]

    def calculate_financing_cost(self, notional: float = 100000, days: int = 90,
                                 spread: Optional[float] = None,
                                 sofr_rate: Optional[float] = None) -> Dict[str, float]:
        """Calculate financing cost for synthetic exposure"""
        sofr_rate = sofr_rate or self.sofr_rate
        spread = spread or self.base_spread
        total_rate = sofr_rate + spread
        
        total_cost = self._financing_cost(total_rate, notional, days)
        
        return {
            'total_cost': total_cost,
            'daily_cost': total_cost / days,
            'annual_rate': total_rate,
            'sofr_rate': sofr_rate,
            'spread': spread
        }

    def estimate_spread_from_volatility(self, volatility: Union[float, pd.Series, pd.DataFrame],
                                        base_spread: Optional[float] = None,
                                        vol_coefficient: Optional[float] = None) -> Union[float, pd.Series, pd.DataFrame]:
        """Estimate financing spread based on volatility"""
        base = base_spread or self.base_spread
        coef = vol_coefficient or self.vol_coefficient
        return base + (coef * volatility)

    def calculate_total_cost_of_carry(self, ticker: str, price: float, volatility: float,
                                      dividend_yield: Optional[float] = None,
                                      dividend_yields: Optional[pd.DataFrame] = None,
                                      tax_rate: float = 0.30, days: int = 90,
                                      notional: float = 100000,
                                      sofr_rate: Optional[float] = None,
                                      cash_borrow_rate: Optional[float] = None,
                                      transaction_cost: float = 0.001) -> Dict[str, Any]:
        """Compare all-in costs: synthetic vs cash"""
        sofr_rate = sofr_rate or self.sofr_rate
        cash_borrow_rate = cash_borrow_rate or sofr_rate

        # Calculate dividend yield if not provided
        if dividend_yield is None:
            dividend_yield = self._get_dividend_yield(
                ticker, price, dividend_yields if dividend_yields is not None else pd.DataFrame()
            )

        # Synthetic costs
        spread = self.estimate_spread_from_volatility(volatility)
        synthetic_rate = sofr_rate + spread
        gross_financing = self._financing_cost(synthetic_rate, notional, days)

        dividend_advantage = dividend_yield * tax_rate
        period_advantage = dividend_advantage * notional * (days / 365)
        transaction_cost_amount = transaction_cost * notional
        total_synthetic_cost = gross_financing - period_advantage + transaction_cost_amount

        # Cash costs
        total_cash_long = self._financing_cost(sofr_rate, notional, days) + transaction_cost_amount
        total_cash_short = self._financing_cost(cash_borrow_rate, notional, days) + transaction_cost_amount

        # Determine cheapest
        costs = [
            ('SYNTHETIC', total_synthetic_cost),
            ('CASH_LONG', total_cash_long),
            ('CASH_SHORT', total_cash_short)
        ]
        cheapest = min(costs, key=lambda x: x[1])

        return {
            'ticker': ticker,
            'date': pd.Timestamp.now().strftime('%Y-%m-%d'),
            'price': price,
            'volatility': volatility,
            'dividend_yield': dividend_yield,
            'estimated_spread': spread,
            'synthetic_rate': synthetic_rate,
            'synthetic_cost': total_synthetic_cost,
            'cash_long_cost': total_cash_long,
            'cash_short_cost': total_cash_short,
            'savings_vs_long': total_cash_long - total_synthetic_cost,
            'savings_vs_short': total_cash_short - total_synthetic_cost,
            'recommendation': cheapest[0],
            'basis': synthetic_rate - cash_borrow_rate,
            'dividend_advantage_rate': dividend_advantage,
            'dividend_advantage_annual': dividend_advantage * notional,
            'dividend_advantage_period': period_advantage
        }

    def batch_cost_analysis(self, tickers: List[str], prices: pd.DataFrame,
                            volatilities: pd.DataFrame, dividend_yields: Optional[pd.DataFrame] = None,
                            **kwargs) -> pd.DataFrame:
        """Run cost analysis for multiple tickers"""
        results = []
        
        for ticker in tickers:
            if ticker not in prices.columns or ticker not in volatilities.columns:
                continue
                
            try:
                result = self.calculate_total_cost_of_carry(
                    ticker=ticker,
                    price=prices[ticker].iloc[-1],
                    volatility=volatilities[ticker].iloc[-1],
                    dividend_yields=dividend_yields,
                    **kwargs
                )
                results.append(result)
            except:
                continue
        
        return pd.DataFrame(results) if results else pd.DataFrame()

    def calculate_basis(self, synthetic_rate: float, cash_rate: float) -> float:
        """Calculate basis between synthetic and cash rates"""
        return synthetic_rate - cash_rate

    def calculate_historical_basis(self, tickers: List[str], prices: pd.DataFrame,
                                   volatilities: pd.DataFrame,
                                   dividend_yields: Optional[pd.DataFrame] = None,
                                   sofr_rates: Optional[pd.Series] = None,
                                   cash_rates: Optional[pd.Series] = None,
                                   days: int = 90, tax_rate: float = 0.30) -> pd.DataFrame:
        """Calculate historical basis over time"""
        basis_data = []
        
        for ticker in tickers:
            if ticker not in prices.columns or ticker not in volatilities.columns:
                continue

            ticker_prices = prices[ticker].dropna()
            ticker_vols = volatilities[ticker].dropna()
            common_dates = ticker_prices.index.intersection(ticker_vols.index)

            for date in common_dates:
                try:
                    price = ticker_prices.loc[date]
                    vol = ticker_vols.loc[date]

                    sofr = self.sofr_rate
                    if sofr_rates is not None and date in sofr_rates.index:
                        sofr = sofr_rates.loc[date]

                    cash = sofr
                    if cash_rates is not None and date in cash_rates.index:
                        cash = cash_rates.loc[date]

                    spread = self.estimate_spread_from_volatility(vol)
                    synthetic_rate = sofr + spread

                    div_yield = self._get_dividend_yield(ticker, price, dividend_yields) if dividend_yields is not None else 0.0

                    dividend_advantage = div_yield * tax_rate
                    effective_synthetic_rate = synthetic_rate - dividend_advantage
                    basis = effective_synthetic_rate - cash

                    basis_data.append({
                        'date': date,
                        'ticker': ticker,
                        'price': price,
                        'volatility': vol,
                        'synthetic_rate': synthetic_rate,
                        'effective_synthetic_rate': effective_synthetic_rate,
                        'cash_rate': cash,
                        'basis': basis,
                        'dividend_yield': div_yield,
                        'spread': spread
                    })
                except:
                    continue

        return pd.DataFrame(basis_data) if basis_data else pd.DataFrame()

    def generate_basis_signals(self, basis_series: pd.Series, entry_threshold: float = 0.01,
                               exit_threshold: float = 0.0025,
                               lookback_days: int = 252) -> pd.DataFrame:
        """Generate trading signals based on basis levels"""
        signals = pd.DataFrame(index=basis_series.index)
        signals['basis'] = basis_series
        signals['mean'] = basis_series.rolling(lookback_days, min_periods=20).mean()
        signals['std'] = basis_series.rolling(lookback_days, min_periods=20).std()
        signals['zscore'] = (basis_series - signals['mean']) / signals['std']

        signals['signal'] = 0
        signals.loc[basis_series < -entry_threshold, 'signal'] = 1
        signals.loc[basis_series > entry_threshold, 'signal'] = -1
        signals.loc[basis_series.abs() < exit_threshold, 'signal'] = 0
        signals['position'] = signals['signal'].replace(0, np.nan).ffill().fillna(0)

        return signals

    def run_full_pricing_analysis(self, data: Dict[str, Any], days: int = 90,
                                  notional: float = 100000, tax_rate: float = 0.30,
                                  transaction_cost: float = 0.001,
                                  include_historical_basis: bool = True,
                                  generate_signals: bool = True,
                                  entry_threshold: float = 0.01,
                                  exit_threshold: float = 0.0025) -> Dict[str, Any]:
        """
        Run complete synthetic pricing analysis
        
        Takes output from DataPipeline and produces comprehensive pricing comparison
        
        Parameters:
        -----------
        data : Dict from DataPipeline.run_full_pipeline()
        days : Holding period for cost calculation (default: 90)
        notional : Position size in dollars (default: 100,000)
        tax_rate : Tax rate on dividends (default: 30%)
        transaction_cost : Transaction cost as % of notional (default: 0.1%)
        include_historical_basis : Calculate basis over time (default: True)
        generate_signals : Generate trading signals (default: True)
        entry_threshold : Basis threshold for signal entry (default: 1%)
        exit_threshold : Basis threshold for signal exit (default: 0.25%)
        
        Returns:
        --------
        Dictionary containing:
            - current_analysis: DataFrame with current cost comparison for all tickers
            - spread_stats: DataFrame with spread statistics by ticker
            - historical_basis: DataFrame with basis over time (if requested)
            - signals: Dict of DataFrames with trading signals per ticker (if requested)
            - summary: Dict with aggregate statistics
        """

        print("\nRunning full pricing analysis...")
        print(f"Parameters: {days} days, ${notional:,.0f} notional, {tax_rate:.0%} tax\n")

        # Extract data components
        prices = data['prices']
        volatilities = data['volatility']
        dividend_yields = data['dividend_yields']
        tickers = list(volatilities.columns)

        print(f"Analyzing {len(tickers)} tickers")

        # Current cost analysis
        current_analysis = self.batch_cost_analysis(
            tickers=tickers, prices=prices, volatilities=volatilities,
            dividend_yields=dividend_yields, days=days, notional=notional,
            tax_rate=tax_rate, transaction_cost=transaction_cost
        )

        # Spread statistics
        spreads = self.estimate_spread_from_volatility(volatilities)
        spread_stats = pd.DataFrame({
            'current_spread': spreads.iloc[-1],
            'mean_spread': spreads.mean(),
            'min_spread': spreads.min(),
            'max_spread': spreads.max(),
            'spread_range': spreads.max() - spreads.min()
        })

        # Historical basis
        historical_basis = pd.DataFrame()
        if include_historical_basis:
            historical_basis = self.calculate_historical_basis(
                tickers=tickers, prices=prices, volatilities=volatilities,
                dividend_yields=dividend_yields if not dividend_yields.empty else None,
                sofr_rates=None, cash_rates=None, days=days, tax_rate=tax_rate
            )

            if not historical_basis.empty:
                cache_file = f"{config.PATH_CONFIG['processed_data_path']}/historical_basis.csv"
                historical_basis.to_csv(cache_file, index=False)

        # Generate signals
        signals_dict = {}
        if generate_signals and not historical_basis.empty:
            for ticker in tickers:
                ticker_basis = historical_basis[historical_basis['ticker'] == ticker].set_index('date')['basis']
                if len(ticker_basis) > 50:
                    signals = self.generate_basis_signals(
                        basis_series=ticker_basis,
                        entry_threshold=entry_threshold,
                        exit_threshold=exit_threshold
                    )
                    signals_dict[ticker] = signals

        # Create summary statistics
        summary = {
            'num_tickers': len(tickers),
            'analysis_date': pd.Timestamp.now().strftime('%Y-%m-%d'),
            'holding_period_days': days,
            'notional': notional,
            'tax_rate': tax_rate,
        }

        if not current_analysis.empty:
            summary.update({
                'avg_synthetic_cost': current_analysis['synthetic_cost'].mean(),
                'avg_cash_long_cost': current_analysis['cash_long_cost'].mean(),
                'avg_basis': current_analysis['basis'].mean(),
                'recommendations': current_analysis['recommendation'].value_counts().to_dict(),
                'total_savings_vs_long': current_analysis['savings_vs_long'].sum(),
            })

        if not spread_stats.empty:
            summary['avg_spread'] = spread_stats['mean_spread'].mean()

        if not current_analysis.empty and 'dividend_advantage_annual' in current_analysis.columns:
            summary['total_dividend_advantage'] = current_analysis['dividend_advantage_annual'].sum()

        # Print summary
        print("\nAnalysis complete")
        
        if not current_analysis.empty:
            print(f"Average synthetic cost: ${summary['avg_synthetic_cost']:,.2f}")
            print(f"Average cash long cost: ${summary['avg_cash_long_cost']:,.2f}")
            print(f"Average basis: {summary['avg_basis']:.2%}")
            print(f"Total potential savings: ${summary['total_savings_vs_long']:,.2f}")
            if 'total_dividend_advantage' in summary:
                print(f"Total dividend advantage: ${summary['total_dividend_advantage']:,.2f}")

        if not historical_basis.empty:
            print(f"Historical basis calculated: {len(historical_basis):,} data points")

        if signals_dict:
            print(f"Trading signals generated for {len(signals_dict)} tickers\n")

        return {
            'current_analysis': current_analysis,
            'spread_stats': spread_stats,
            'historical_basis': historical_basis,
            'signals': signals_dict,
            'summary': summary
        }